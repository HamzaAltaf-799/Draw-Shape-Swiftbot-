import swiftbot.SwiftBotAPI;
import swiftbot.Button;
import java.awt.image.BufferedImage;
import java.util.*;

public class X {
	static SwiftBotAPI bot;
	static Scanner scanner = new Scanner(System.in);

	static List<String> ShapeData = new ArrayList<>();
	static Map<String, Integer> NoofShape = new HashMap<>();
	static List<Long> TimeTaken = new ArrayList<>();
	static double LargestArea = 0;
	static String LargestShape = "";

	static class Shape {
		String type; // "S" for Square, "T" for Triangle
		int[] sides;

		Shape(String type, int[] dimensions) {
			this.type = type;
			this.sides = dimensions;
		}

		void displayShape() {
			if (type.equals("S")) {
				System.out.println("Square: " + sides[0] + " cm");
			} else if (type.equals("T")) {
				System.out.println("Triangle: " + sides[0] + ", " + sides[1] + ", " + sides[2] + " cm");
			}
		}
	}

	public static void main(String[] args) {
		try {
			bot = new SwiftBotAPI();

			bot.enableButton(Button.X, () -> {
				System.out.println("Exit button (X) pressed. Exiting...");
				generateSummary();
				safeExit();
			});

			while (true) {
				System.out.println("----------------------------------------");
				System.out.println("     SWIFTBOT DRAW SHAPE PROGRAM        ");
				System.out.println("----------------------------------------");
				System.out.println("  Please select one of the methods to enter data  ");
				System.out.println("  Press [1] if you want to scan a QR  ");
				System.out.println("  Press [2] if you want to type in the data  ");
				System.out.println("  Press [X] at any time to terminate the program ");
				System.out.println("========================================");
				String methodChoice = scanner.nextLine();
				String userInput = "";

				if (methodChoice.equals("1")) {
					userInput = scanQRCode();
				} else if (methodChoice.equals("2")) {
					System.out.println("PLEASE ENTER THE DATA ");
					System.out.println("Follow this format");
					System.out.println(" S-XX or T-XX-YY-ZZ ~~ If multiple shapes separate it by ' & '");
					userInput = scanner.nextLine();
				} else if (methodChoice.equalsIgnoreCase("X")) {
					generateSummary();
					safeExit();
					return;
				} else {
					System.out.println(" -- unrecognized input --");
					System.out.println("----Please ensure it contains valid shape data (e.g., S-16 or T-16-30-24)----");
					System.out.println("--- TRY AGAIN ---");
					continue;
				}

				List<Shape> shapes = processShapes(userInput);
				if (shapes.isEmpty()) {
					System.out.println("Could not recognize a valid shape");
					continue;
				}

				drawMultipleShapes(shapes);
				boolean inSubMenu = true;
				while (inSubMenu) {
					System.out.println("---------- DONE ----------");
					System.out.println("Now press [1] to same Redraw shapes");
					System.out.println("To draw a new shape press [2]");
					System.out.println("To terminate press [X]");

					String choice = scanner.nextLine();
					if (choice.equals("1")) {
						drawMultipleShapes(shapes);
					} else if (choice.equals("2")) {
						inSubMenu = false; // Go back to shape input
					} else if (choice.equals("X")) {
						safeExit();
						return;
					} else {
						System.out.println("Could not recognize a valid input. Please enter 1, 2, or 3.");
					}
				}
			}
		} catch (Exception e) {
			System.out.println(" ----------UNEXPECTED ERROR---------- ");
		}
	}

	public static void safeExit() {
		System.out.println("----- PROGRAM TERMINATED ----------");
		generateSummary();
		scanner.close();
		System.exit(0);
	}

	public static String scanQRCode() {
		long startTime = System.currentTimeMillis();
		long endTime = startTime + 10000; // 10 seconds timeout

		System.out.println(" Place QR in front of camera");

		try {
			while (System.currentTimeMillis() < endTime) {
				BufferedImage img = bot.getQRImage(); // Capture QR image
				String qrData = bot.decodeQRImage(img); // Decode QR image

				if (!qrData.isEmpty()) {
					System.out.println(" QR DETECTED ");
					System.out.println("Decoded message: " + qrData);
					return qrData;
				} else {
					System.out.println("----- NO QR DETECTED -----");
				}

				Thread.sleep(1000); // Wait for 1 second before retrying
			}

			System.out.println("----- NOT ABLE TO DETACT A QR -----");
			System.out.println("        Use other methods         ");
			return ""; // Return empty string if no QR was found

		} catch (Exception e) {
			System.out.println("----- NOT ABLE TO DETACT A QR -----");
			System.out.println("------- Use other methods -------  ");
			e.printStackTrace();
			return ""; // Return empty string in case of failure
		}
	}

	public static List<Shape> processShapes(String data) {
		List<Shape> shapes = new ArrayList<>();
		String[] shapeDataArray = data.split("&");

		for (int i = 0; i < shapeDataArray.length; i++) {
			String shapeData = shapeDataArray[i].trim();
			try {
				if (shapeData.startsWith("S-")) {
					int slength = Integer.parseInt(shapeData.substring(2).trim());
					if (slength >= 15 && slength <= 85) {
						shapes.add(new Shape("S", new int[] { slength }));
					} else {
						System.out.println("Lenght out of range (must be 15-85 cm)");
					}
				} else if (shapeData.startsWith("T-")) {
					String[] parts = shapeData.substring(2).split("-");
					if (parts.length == 3) {
						int T1 = Integer.parseInt(parts[0].trim());
						int T2 = Integer.parseInt(parts[1].trim());
						int T3 = Integer.parseInt(parts[2].trim());

						if (T1 + T2 > T3 && T1 + T3 > T2 && T2 + T3 > T1) {
							shapes.add(new Shape("T", new int[] { T1, T2, T3 }));
						} else {
							System.out.println("Can not form a triangle with these lenght");
						}
					}
				} else {
					System.out.println("Invalid format: " + shapeData);
				}
			} catch (NumberFormatException e) {
				System.out.println("INPUT ERROR: " + shapeData);
			}
		}
		return shapes;
	}

	public static void drawMultipleShapes(List<Shape> shapes) {
		for (int i = 0; i < shapes.size(); i++) {
			Shape shape = shapes.get(i);
			long startTime = System.currentTimeMillis();
			shape.displayShape();

			if (shape.type.equals("S")) {
				drawSquare(shape.sides[0]);
				updateStats("Square", shape.sides[0] * shape.sides[0], startTime);
			} else if (shape.type.equals("T")) {
				drawTriangle(shape.sides[0], shape.sides[1], shape.sides[2]);
				double area = calculateTriangleArea(shape.sides[0], shape.sides[1], shape.sides[2]);
				updateStats("Triangle", area, startTime);
			}

			if (i < shapes.size() - 1) {
				System.out.println("== MOVING BACK ==");

				bot.move(-45, -50, 940); // Adjust speed as needed for smooth movement
				bot.stopMove();
			}
		}
	}

	public static void flashRedLight(int times) {
		for (int i = 0; i < times; i++) {
			bot.fillUnderlights(new int[] { 255, 0, 0 }); // Turn on red light
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
			}

			bot.fillUnderlights(new int[] { 0, 0, 0 }); // Turn off light
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
			}
		}
	}

	public static void flashgreenLight(int times) {
		for (int i = 0; i < times; i++) {
			bot.fillUnderlights(new int[] { 0, 255, 0 }); // Turn on red light
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
			}
			bot.fillUnderlights(new int[] { 0, 0, 0 }); // Turn off light
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
			}
		}
	}

	public static int[] SelectSpeed(int TotalDistance) {
		System.out.println(" WHAT SPEED YOU WANT SWIFTBOT TO MOVE ");
		System.out.println("Press [1] for High Speed (Speed +5)");
		System.out.println("Press [2] for Low Speed (Speed -5)");
		System.out.println("And if normal Speed press [3]");

		int speed = 0;
		int calibration = 0;
		String speedChoice = scanner.nextLine().trim();
		if (TotalDistance * 4 >= 200) {
			speed = 50;
			calibration = 50;
		} else {
			speed = 60;
			calibration = 40;
		}
		if (speedChoice.equals("1")) {
			speed += 5;
			calibration += 5;
			System.out.println("===== HIGH SPEED SUCCESSFULL SELECTED =====");
		} else if (speedChoice.equals("2")) {
			speed -= 5;
			calibration -= 5;
			System.out.println("===== LOW SPEED SUCCESSFULL SELECTED =====");
		} else {
			System.out.println("===== SPEED SUCCESSFULL SELECTED =====");
		}
		return new int[] { speed, calibration };

	}

	public static void drawSquare(int sideLength) {

		int TotalDistance = sideLength * 4;

		int[] speedConfig = SelectSpeed(TotalDistance);
		int speed = speedConfig[0];
		int calibration = speedConfig[1];
		System.out.println("Drawing square of side: " + sideLength + " cm at speed: " + speed);
		flashRedLight(3);
		displaySquareProgress(sideLength);

		for (int i = 0; i < 4; i++) {
			bot.fillUnderlights(new int[] { 255, 255, 0 }); // Yellow underlight while drawing
			bot.move(speed - 6, speed, sideLength * calibration);
			bot.stopMove();
			System.out.println("TURNING RIGHT");
			bot.move(-70, 70, 455);

		}

		flashgreenLight(3);
		System.out.println("===== SQUARE DRAWING HAS BEEN COMPLETED ====");
	}

	public static void displaySquareProgress(int sideLength) {
		int printSize = Math.min(sideLength / 3, 10);
		System.out.println("~~~~ DRAWING IN PROCESS ~~~~");
		for (int i = 0; i < printSize; i++) {
			if (i == 0 || i == printSize - 1) {
				System.out.println("+" + "-".repeat(printSize) + "+");
			} else {
				System.out.println("|" + " ".repeat(printSize) + "|");
			}
		}
	}

	public static void drawTriangle(int t1, int t2, int t3) {

		int TotalDistance = t1 + t2 + t3;

		int[] speedConfig = SelectSpeed(TotalDistance);
		int speed = speedConfig[0];
		int calibration = speedConfig[1];

		int a1 = 180 - calculateAngle(t2, t3, t1);
		int a2 = 180 - calculateAngle(t1, t3, t2);

		System.out.println("Drawing Triangle of sides " + t1 + ", " + t2 + ", " + t3 + " at speed " + speed);

		flashRedLight(3); // Red underlight

		// Display triangle representation
		drawAsciiTriangle(t1, t2, t3);
		bot.fillUnderlights(new int[] { 255, 255, 0 }); // Yellow under light to indicate drawing under process
		// Move along the first side
		bot.move(speed - 5, speed, t1 * calibration);
		bot.stopMove();

		bot.move(50, -50, a1 * 5); // multiply by 5 to calibrate angle so it can turn
		bot.stopMove();

		// Move along the second side
		bot.move(speed - 5, speed, t2 * calibration);
		bot.stopMove();

		bot.move(50, -50, a2 * 5);
		bot.stopMove();

		// Move along the third side
		bot.move(speed - 5, speed, t3 * calibration);
		bot.stopMove();

		// Set underlight to red to indicate completion
		flashgreenLight(3);
		System.out.println("===== TRIANGLE DRAWING HAS BEEN COMPLETED ====");

	}

	// Displays an ASCII representation of a triangle.

	public static void drawAsciiTriangle(int a, int b, int c) {
		int height = Math.min(Math.max(a, b) / 3, 10); // Scale for CLI
		System.out.println("~~~~ DRAWING IN PROCESS ~~~~");
		for (int i = 0; i < height; i++) {
			int width = (i * 2) + 1;
			int spaces = (height - i);
			System.out.println(" ".repeat(spaces) + "*".repeat(width));
		}
		System.out.println();
	}

	private static int calculateAngle(int a, int b, int c) {
		double cosValue = (Math.pow(a, 2) + Math.pow(b, 2) - Math.pow(c, 2)) / (2.0 * a * b);
		return (int) Math.round(Math.toDegrees(Math.acos(cosValue)));
	}

	private static void updateStats(String shapeName, double area, long startTime) {
		long endTime = System.currentTimeMillis();
		long timeTaken = endTime - startTime;

		ShapeData.add(shapeName + " - Size: " + area + " cm² - Time: " + timeTaken + "ms");
		TimeTaken.add(timeTaken);

		NoofShape.put(shapeName, NoofShape.getOrDefault(shapeName, 0) + 1);

		if (area > LargestArea) {
			LargestArea = area;
			LargestShape = shapeName + " (Size: " + area + " cm²)";
		}
	}

	public static void generateSummary() {
		System.out.println("\n===== SUMMARY REPORT =====");
		System.out.println("Shapes drawn in order:");
		for (String log : ShapeData) {
			System.out.println(log);
		}

		String mostFrequentShape = NoofShape.entrySet().stream().max(Map.Entry.comparingByValue())
				.map(Map.Entry::getKey).orElse("None");

		long totalTime = TimeTaken.stream().mapToLong(Long::longValue).sum();
		double averageTime = TimeTaken.isEmpty() ? 0 : (double) totalTime / TimeTaken.size();

		System.out.println("\nLargest Shape: " + (LargestShape.isEmpty() ? "None" : LargestShape));
		System.out.println("Most Frequent Shape: " + mostFrequentShape + " (Count: "
				+ NoofShape.getOrDefault(mostFrequentShape, 0) + ")");
		System.out.println("Average Time Per Shape: " + String.format("%.2f", averageTime) + "ms");
		System.out.println("====================================================================");
	}

	private static double calculateTriangleArea(int a, int b, int c) {
		double s = (a + b + c) / 2.0;
		return Math.sqrt(s * (s - a) * (s - b) * (s - c));
	}
}
